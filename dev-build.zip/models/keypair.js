(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var KeyPair = exports.KeyPair = function () {
	function KeyPair() {
		_classCallCheck(this, KeyPair);

		this.publicKey = null;
		this.privateKey = null;
		this.accounts = null;

		this.removed = null;
	}

	_createClass(KeyPair, [{
		key: 'getHighestAuthority',
		value: function getHighestAuthority() {
			return this.accounts.length ? this.accounts[0].authority.toLowerCase() : 'No account found';
		}
	}, {
		key: 'hasOwnerAuthority',
		value: function hasOwnerAuthority() {
			return this.getHighestAuthority().toLowerCase() === 'owner';
		}
	}, {
		key: 'remove',
		value: function remove() {
			this.removed = true;
		}
	}, {
		key: 'revertRemoval',
		value: function revertRemoval() {
			this.removed = false;
		}
	}, {
		key: 'clone',
		value: function clone() {
			return KeyPair.fromJson(Object.assign({}, this));
		}
	}, {
		key: 'setAccounts',
		value: function setAccounts(accounts) {
			this.accounts = this.sortAccounts(accounts);
		}
	}, {
		key: 'sortAccounts',
		value: function sortAccounts(accounts) {
			return Object.assign([], accounts).sort(function (a, b) {
				return (Authorities[a.authority.toLowerCase()] || 0) < Authorities[b.authority.toLowerCase()] || 0;
			});
		}
	}], [{
		key: 'placeholder',
		value: function placeholder() {
			var p = new KeyPair();
			p.publicKey = '';
			p.privateKey = '';
			p.accounts = [];
			return p;
		}
	}, {
		key: 'fromJson',
		value: function fromJson(json) {
			return Object.assign(this.placeholder(), json);
		}
	}, {
		key: 'fromPair',
		value: function fromPair(priv, pub) {
			var p = this.placeholder();
			p.privateKey = priv;
			p.publicKey = pub;
			return p;
		}
	}]);

	return KeyPair;
}();

var Authorities = { owner: 2, active: 1 };

},{}]},{},[1]);
