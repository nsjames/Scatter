(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

var InputComponent = {
    template: require('../partials/input.html'),
    data: function data() {
        return { input: this.inputText };
    },

    methods: { changed: function changed() {
            this.$emit('changed', this.input);
        } },
    props: ['icon', 'type', 'placeholder', 'inputText', 'isHalf', 'disabled'],
    watch: { input: function input(n, o) {
            this.changed();
        } }
};

module.exports = InputComponent;

},{"../partials/input.html":2}],2:[function(require,module,exports){
"use strict";

module.exports = "\n<section class=\"input-container\" :class=\"{'half':isHalf}\">\n  <figure class=\"icon\" v-if=\"icon\"><i class=\"fa\" :class=\"icon\"></i></figure>\n  <input :disabled=\"disabled\" :class=\"{'with-icon':icon}\" :placeholder=\"placeholder\" :type=\"type\" v-model=\"input\" />\n</section>\n";

},{}]},{},[1]);
