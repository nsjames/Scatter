(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

var SelectComponent = {
    template: require('../partials/select.html'),
    data: function data() {
        return {
            open: false,
            selectedOption: this.options[0]
        };
    },

    methods: {
        close: function close() {
            this.open = false;
        },
        toggle: function toggle() {
            this.open = !this.open;
        },
        selectOption: function selectOption(option) {
            console.log("OPTION", option);
            this.selectedOption = option;
            this.changed();
            this.close();
        },
        changed: function changed() {
            this.$emit('changed', this.selectedOption);
        }
    },
    props: ['options'],
    watch: { input: function input(n, o) {
            this.changed();
        } }
};

module.exports = SelectComponent;

},{"../partials/select.html":2}],2:[function(require,module,exports){
"use strict";

module.exports = "\n<section class=\"select\" :class=\"{'open':open}\">\n  <figure class=\"item\" v-on:click=\"toggle\">{{selectedOption}}</figure>\n  <figure class=\"arrow\" v-on:click=\"toggle\"><i class=\"fa fa-caret-down\"></i></figure>\n\n  <section class=\"options\" :class=\"{'show':open}\">\n    <figure class=\"item\" v-on:click=\"selectOption(option)\" v-for=\"option in options\">{{option}}</figure>\n  </section>\n</section>\n";

},{}]},{},[1]);
